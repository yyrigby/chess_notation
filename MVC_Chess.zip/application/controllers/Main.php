<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	public function index()
	{
		$this->load->view('header');
		$this->load->view('index');
	}

	public function update_game() {
		$this->output->enable_profiler();
		$pgnData = $this->input->post();
		var_dump($pgnData);
		echo 'hi';
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */